# FlappyBird

Flappy Bird made with Godot Mono (C#)

![img](https://i.imgur.com/0UlPfoa.png)
## How to run the project with Godot

1. Install Godot stable v3.5 mono
2. Install MSBUILD VS TOOLS
3. If you have any problem try to clear AppData/Local/Godot
4. Also try deleting your .mono/ folder in project directory if (3) does not work
