using Godot;
using System;
using ai4u;

public class FlappyBirdController : Controller
{
    	[Export]
		public string actuatorName = "FlappyBird";


		private float reward_sum = 0;
		override public string GetAction()
		{
			bool actionValue = false;
			string actionName = actuatorName;

			if (Input.IsKeyPressed((int)KeyList.U))
			{
				actionValue = true;
			}

			if (Input.IsKeyPressed((int)KeyList.R))
			{
				actionName = "__restart__";
			}

			if (actionName != "__restart__")
			{
				return ai4u.Utils.ParseAction(actionName, actionValue);
			} else
			{
				return ai4u.Utils.ParseAction("__restart__");
			}
		}

		override public void NewStateEvent()
		{
			int n = GetStateSize();
			for (int i = 0; i < n; i++)
			{
				if (GetStateName(i) == "reward" || GetStateName(i) == "score")
				{
					float r = GetStateAsFloat(i);
					reward_sum += r;
				}
				else if (GetStateName(i) == "done" && GetStateAsFloat(i) > 0)
				{
					GD.Print("Reward Episode: " + reward_sum);
					reward_sum = 0;
				}
			}
		}
}
