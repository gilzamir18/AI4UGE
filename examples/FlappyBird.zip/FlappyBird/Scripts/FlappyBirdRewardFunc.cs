using Godot;
using System;
using ai4u;

public class FlappyBirdRewardFunc : RewardFunc
{
    private BasicAgent agent;

    [Export] private float rewardAmount = 10;

    private float acmReward = 0.0f;


    public float Amount 
    {
        get
        {
            return rewardAmount;
        }
    }


    public void AddReward(float r)
    {   
        acmReward += r;
    }

    public override void OnSetup(Agent agent)
    {	
        this.agent = (BasicAgent) agent;
        agent.AddResetListener(this);
    }
    
    public override void OnReset(Agent agent)
    {
        acmReward = 0.0f;
    }
    
    public override void OnUpdate()
    {
        agent.AddReward(acmReward, this); 
        acmReward = 0;
    }
}
