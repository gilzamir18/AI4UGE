using Godot;
using System;
using ai4u;

public class FlappyBirdActuator : Actuator
{

    	private BasicAgent agent;
        private FlappyBird.Bird bird;
        
        public override void OnSetup(Agent agent)
		{
			shape = new int[1]{2};
			isContinuous = false;
			rangeMin = new float[]{};
			rangeMax = new float[]{};
			this.agent = (BasicAgent) agent;
			agent.AddResetListener(this);
		}

		public void SetBird(FlappyBird.Bird b)
		{
			bird = b;
		}

		public override void Act()
		{
			if (bird != null && agent != null && !agent.Done)
			{
				if (agent.GetActionArgAsFloatArray()[0] > 0 )
				{
					if (bird.JumpTimer.IsActive())
					{
						return;
					}
					bird.JumpTimer.Start();
					bird.ApplyCentralImpulse(bird.JumpForce);
				}
			}
		}
}
