import ai4u
from ai4u.controllers import BasicGymController
import AI4UEnv
import gym
import numpy as np
from stable_baselines3 import DQN

env = gym.make("AI4UEnv-v0", buffer_size=81920)

model = DQN("CnnPolicy", env, verbose=1)
model.learn(total_timesteps=1000000, log_interval=4)
model.save("dqn_model")

del model # remove to demonstrate saving and loading

model = DQN.load("dqn_model", sleep=0)

obs = env.reset()
while True:
    action, _states = model.predict(obs, deterministic=True)
    obs, reward, done, info = env.step(action)
    env.render()
    if done:
      obs = env.reset()

